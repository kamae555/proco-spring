package com.example.procospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcoSpringApplication.class, args);
	}

}
